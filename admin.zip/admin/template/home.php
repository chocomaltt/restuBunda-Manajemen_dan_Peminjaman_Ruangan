<html>
    <head>
        <!-- <link rel="stylesheet" href="../../assets/css/custom_color.css"> -->
    </head>
    <body class="container-fluid bg-user-default m-0 p-0" style="">
        <div class="d-flex vw-100 vh-100">
            <div class="w-25 h-100 m-0 p-0">
                <?php
                    include "sidebar.php";
                    ?>
            </div>
            <div class="d-flex flex-column w-100 h-100">
                <?php
                include "header.php";
                    // include "beranda.php";
                    // include "daftar-ruang.php";
                    // include "jadwal-ruang.php";
                    include "denah-ruang.php";
                ?>
            </div>
        </div>
    </body>
</html>