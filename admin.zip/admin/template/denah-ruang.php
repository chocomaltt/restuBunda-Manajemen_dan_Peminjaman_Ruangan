<div class="position-absolute end-0 w-100 vh-100" style="z-index: 30; max-width: 80%;">
    <div class="w-100 vh-100 position-relative" style="z-index: 20;margin-top: 59px; padding: 0 30px;">
        <div class="w-75" style=" justify-content: start; margin: 4rem 25 0 23  rem;">
            <p class="text-white fw-bold fs-2">DAFTAR RUANG</p>
        </div>
        <div class="container" style="padding: 40px 100px;">
            <div class="row row-cols-2 d-flex justify-content-start">
                <div class="col">
                    <img src="../../assets/img/denah gedung TI 5-6-7-8-1.png" alt="" style="width: 80%; margin: 30px;">
                </div>
                <div class="col">
                    <img src="../../assets/img/denah gedung TI 5-6-7-8-1.png" alt="" style="width: 80%; margin: 30px;">
                </div>
                <div class="col">
                    <img src="../../assets/img/denah gedung TI 5-6-7-8-1.png" alt="" style="width: 80%; margin: 30px;">
                </div>
            </div>
        </div>
    </div>
</div>